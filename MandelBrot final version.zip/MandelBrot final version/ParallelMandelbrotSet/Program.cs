﻿
using System.Diagnostics;
using System.IO;
using System.Numerics;
using SixLabors.ImageSharp;
using System.Collections.Concurrent;
using System.Reflection;
using System.Threading;
using System.Threading.Tasks;
using SixLabors.ImageSharp.PixelFormats;
using System;


namespace ParallelMandelbrotSet
{
    class Program
    {
        class MandelbrotScale
        {
            //Oпределя Частта от комплексната равнина, показана на изображенията е определена от
            public MandelbrotScale(double lx, double hx, double ly, double hy)
            {
                Xreal = lx;
                Ximaginary = hx;
                Yreal = ly;
                Yimaginary = hy;
            }

            public double Xreal { get; set; }
            public double Ximaginary { get; set; }
            public double Yreal { get; set; }
            public double Yimaginary { get; set; }
        }

        // kolko iteracii da ima v1tre6niq cik1l
        const int iterations = 2000;
        static int width = 500;
        static int height = 500;
        // Verbose output
        static bool seeMessages = false;

        // Режим на тестване
        static bool benchmark = false;
        static int depth = 2;
        static int numberOftasks = 10;
        static string path = Path.GetDirectoryName(Assembly.GetEntryAssembly().Location) + '\\' + "Mandelbrot17task.png";
        //Частта от комплексната равнина, показана на изображенията е определена от
        static MandelbrotScale scale = new MandelbrotScale(-2.0, 2.0, -2.0, 2.0);

        static void Main(string[] args)
        {
           
            ParseArgs(args);

            if(benchmark)
            {
                PerformTest(1);
                Console.WriteLine("Press any key to continue...");
                Console.ReadLine();
                return;
            }

            var fileStream = new FileStream(path, FileMode.Create, FileAccess.Write);
            if(numberOftasks < 2)
            {
                Time(() =>
                    MandelbrothDepict(width, height, fileStream, scale),
                    nameof(MandelbrothDepict),
                    0, 1);
            }
            else
            {
                Time(() =>
                DrawMandelbrotSetParallel(width, height, fileStream, numberOftasks, depth, scale),
                nameof(DrawMandelbrotSetParallel),
                depth,
                numberOftasks);
            }

            Console.WriteLine("Press any key to continue...");
            Console.ReadLine();
        }

        static void PerformTest(int testUntil)
        {
            var fileStream = new FileStream(path, FileMode.Create, FileAccess.Write);


            var chronometer = Stopwatch.StartNew();
            MandelbrothDepict(width, height, fileStream, scale);
            double t1 = chronometer.ElapsedMilliseconds; //serial
        
 
            for(int f = 2; f <= testUntil; f+=2)
            {
                chronometer.Restart();
                DrawMandelbrotSetParallel(width, height, fileStream, f, depth, scale);
                double tp = chronometer.ElapsedMilliseconds;
                double sp = t1 / tp;
                double ep = sp / f;
                Console.WriteLine($"{f,-5} | {tp,-7} | {sp, -7 : ##.####} | {ep, -7: ##.####}");
            }
            fileStream.Close();
        }

        //Parsva argumentite ot launchSettings.json
        //primer "commandLineArgs": "-s 640x480 -t 16 -o zad17.png -g 2"
        static void ParseArgs(string[] args)
        {
            int temp = 0;

            if ((temp = Array.IndexOf(args, "-r")) != -1 ||
              (temp = Array.IndexOf(args, "-rect")) != -1)
            {
                var scaleStr = args[temp + 1].Split(':');
                scale.Xreal = double.Parse(scaleStr[0]);
                scale.Ximaginary = double.Parse(scaleStr[1]);
                scale.Yreal = double.Parse(scaleStr[2]);
                scale.Yimaginary = double.Parse(scaleStr[3]);
            }

            
            if ((temp = Array.IndexOf(args, "-s")) != -1 ||
                (temp = Array.IndexOf(args, "-size")) != -1)
            {
                var screen = args[temp + 1].Split('x');
                width = int.Parse(screen[0]);
                height = int.Parse(screen[1]);
            }

            if ((temp = Array.IndexOf(args, "-o")) != -1 ||
                (temp = Array.IndexOf(args, "-output")) != -1)
            {
                path = Path.GetDirectoryName(Assembly.GetEntryAssembly().Location) + '\\' + args[temp + 1];

            }

            if ((temp = Array.IndexOf(args, "-t")) != -1 ||
                (temp = Array.IndexOf(args, "-tasks")) != -1)
            {
                numberOftasks = int.Parse(args[temp + 1]);
            }

           

            if (Array.IndexOf(args, "-q") != -1 || Array.IndexOf(args, "-quiet") != -1)
            {
                seeMessages = true;
            } 

            if((temp = Array.IndexOf(args, "-g")) != -1 ||
               (temp = Array.IndexOf(args, "-granularity")) != -1)
            {
                depth = int.Parse(args[temp + 1]);
            }

            if (Array.IndexOf(args, "-test") != -1)
            {
                seeMessages = true;
                benchmark = true;
            }
        }


        static int CalculateAPoint(Complex c)
        {
            var z = new Complex(0, 0);
            var it = 0;
            while (z.Real * z.Real + z.Imaginary * z.Imaginary <= 4 && it < iterations)
            {
                z = Complex.Pow(Complex.Cos(Complex.Multiply(c, z)), Math.E);
                it++;
            }
            return it;
        }


        static void Time(Action action, string function, int chunkSize, int threadCnt)
        {
            var sw = Stopwatch.StartNew();
            action();
            Console.WriteLine("Function                                           |   Total Time     | Depth  | Number of threads ");
            

            Console.WriteLine($"{function,-50} | {sw.Elapsed} | {chunkSize,-10} | {threadCnt} \n");
        }

        static void InnerLoopOfMandelbrotCalculations(int i, int width, int height, Image<Rgba32> image, MandelbrotScale scale)
        {
            for (int j = 0; j < height; j++)
            {
                var cx = ((double)i).Map(0, width, scale.Xreal, scale.Ximaginary);
                var cy = ((double)j).Map(0, height, scale.Yreal, scale.Yimaginary);
                var c = new Complex(cx, cy);
                var iterations = CalculateAPoint(c);

                if (iterations == Program.iterations)
                    image[i, j] = new Rgba32(0, 0, 0);
                else
                {
                    var factor = iterations / (double)Program.iterations;
                    var intensity = (byte)Math.Round(255 * factor * 10);
                    image[i, j] = new Rgba32(intensity, intensity, intensity);
                }
            }
        }


        static void MandelbrothDepict(int width, int height, Stream stream, MandelbrotScale scale)
        {
            if(!seeMessages)
            {
                Console.WriteLine($"Thread {Thread.CurrentThread.ManagedThreadId} started drawing Mandelbrot. \n");
            }


            using (var image = new Image<Rgba32>(width, height))
            {
                for(int i = 1; i <= width+1; i++)
                    InnerLoopOfMandelbrotCalculations(i, width, height, image, scale);

                image.SaveAsPng(stream);
            };
            if (!seeMessages)
            {
                Console.WriteLine($"Thread {Thread.CurrentThread.ManagedThreadId} finished drawing Mandelbrot. \n");
                Console.WriteLine("path" + path);
            }
        }

        static void MandebrotParallelTasks(int width, int height, Stream stream, int taskCnt, MandelbrotScale scale)
        {
            using (var image = new Image<Rgba32>(width, height))
            {
                CustomPartitionParallelFor(0, width, (i) =>
                {
                    InnerLoopOfMandelbrotCalculations(i, width, height, image, scale);
                }, taskCnt);

                image.SaveAsPng(stream);
            };
        }

        static void DrawMandelbrotSetParallel(int width, int height, Stream stream, int taskCnt, int chunkSize, MandelbrotScale scale)
        {
            if (!seeMessages)
            {
                Console.WriteLine($"Thread {Thread.CurrentThread.ManagedThreadId} started picturing   \n");
            }
            using (var image = new Image<Rgba32>(width, height))
            {
                GetACustomPart(0, width, (i) =>
                {
                    InnerLoopOfMandelbrotCalculations(i, width, height, image, scale);
                }, chunkSize, taskCnt);

                image.SaveAsPng(stream);
            };
            if (!seeMessages)
            {
                Console.WriteLine($"Thread {Thread.CurrentThread.ManagedThreadId} is done picturing  \n");
            }
        }

        static void DepictMandelBrotParallel(int width, int height, Stream stream, int taskCnt, int chunkSize, MandelbrotScale scale)
        {
            using (var image = new Image<Rgba32>(width, height))
            {
                Parallel.ForEach(Partitioner.Create(0, width, chunkSize),
                    new ParallelOptions() { MaxDegreeOfParallelism = taskCnt },
                    range =>
                    {
                        for(int i = range.Item1; i < range.Item2; i++)
                            InnerLoopOfMandelbrotCalculations(i, width, height, image, scale);
                    });

                image.SaveAsPng(stream);
            };
        }

 

     


        // Всяка от нишките изчеслява част от равнината
        static void GetACustomPart(int inclusiveLowerBound, int exclusiveUpperBound,
            Action<int> body, int chunkSize, int? threadCnt = null)
        {
            
            int numProcs = threadCnt.HasValue ? threadCnt.Value : Environment.ProcessorCount;
            int remainingWorkItems = numProcs;


            int nextIteration = inclusiveLowerBound;
            using (ManualResetEvent mre = new ManualResetEvent(false))
            {
                
                for (int p = 1; p <= numProcs; p++)
                {
                    ThreadPool.QueueUserWorkItem(delegate
                    {
                        var sw = new Stopwatch();
                        if (!seeMessages)
                        {
                            Console.WriteLine($"Thread {Thread.CurrentThread.ManagedThreadId} started calculating part of the set . \n");
                            sw.Start();
                        }
                        int index;
                        while ((index = Interlocked.Add(ref nextIteration, chunkSize) - chunkSize) < exclusiveUpperBound)
                        {
                            int end = index + chunkSize;
                            if (end >= exclusiveUpperBound) end = exclusiveUpperBound;
                            for (int i = index; i < end; i++) body(i);
                        }
                        if (!seeMessages)
                        {
                            Console.WriteLine($"Thread {Thread.CurrentThread.ManagedThreadId} finished cаlculation . Elapsed time: {sw.ElapsedMilliseconds}ms.\n");
                        }
                        if (Interlocked.Decrement(ref remainingWorkItems) == 0)
                            mre.Set();
                    });
                }
                
                mre.WaitOne();
            }
        }

        public static void CustomPartitionParallelFor(int inclusiveLowerBound, int exclusiveUpperBound,
            Action<int> body, int? threadCnt = null)
        {
            int numProcs = threadCnt.HasValue ? threadCnt.Value : Environment.ProcessorCount;
            int size = exclusiveUpperBound - inclusiveLowerBound;
            int range = size / numProcs;
            
            int remaining = numProcs;
            using (ManualResetEvent mre = new ManualResetEvent(false))
            {
                // Създаване на всяка една от нишките.
                for (int p = 1; p <= numProcs; p++)
                {


                    int start = p * range + inclusiveLowerBound;
                    int end = (p == numProcs - 1) ? exclusiveUpperBound : start + range;
                    ThreadPool.QueueUserWorkItem(delegate
                    {
                        for (int i = start+1; i <= end; i++) body(i);
                        if (Interlocked.Decrement(ref remaining) == 0) mre.Set();
                    });
                }
                // Wait for all threads to complete.
                mre.WaitOne();
            }
        }



    }
}
